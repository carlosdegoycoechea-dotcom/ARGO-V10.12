# FIX PARA BACKEND - ModuleNotFoundError

## Problema
```
ModuleNotFoundError: No module named 'plugins.intelligence'
```

**Ubicación:** `backend/main.py` línea 30

## Causa
El archivo `backend/main.py` intenta importar módulos que no existen:
```python
from backend.intelligence_pipeline import apply_intelligence_pipeline
```

Y dentro de ese archivo (que tampoco existe), intenta:
```python
from plugins.intelligence import (...)
```

## Solución 1: Eliminar Import (RÁPIDA - 30 segundos)

### Paso 1: Abrir `backend/main.py`

### Paso 2: Buscar y ELIMINAR o COMENTAR esta línea (~línea 30):
```python
# ELIMINAR ESTA LÍNEA:
from backend.intelligence_pipeline import apply_intelligence_pipeline
```

### Paso 3: Buscar en el archivo si se usa `apply_intelligence_pipeline`

Si encuentras algo como:
```python
# En alguna parte del código
result = apply_intelligence_pipeline(...)
```

COMÉNTALO:
```python
# result = apply_intelligence_pipeline(...)
# TODO: Implementar intelligence pipeline
```

### Paso 4: Guardar y reiniciar backend

```bash
# Detener backend (Ctrl+C)
# Reiniciar
python -m uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

## Solución 2: Crear Archivos Faltantes (COMPLETA - 5 minutos)

Si prefieres tener la funcionalidad completa, necesitas crear:

1. `backend/intelligence_pipeline.py`
2. `plugins/intelligence/` directorio con plugins

**Ver archivo:** `backend_intelligence_pipeline.py` (incluido en este paquete)

## Verificación

Después del fix, el backend debería iniciar con:
```
INFO:     Uvicorn running on http://0.0.0.0:8000
INFO:     Application startup complete.
✅ ARGO Backend initialized successfully
```

Sin errores de ModuleNotFoundError.
